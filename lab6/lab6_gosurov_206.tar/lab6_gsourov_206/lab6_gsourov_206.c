#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}
int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <random_seed> <array_size>\n", argv[0]);
        return 1;
    }
    int seed = atoi(argv[1]);
    int size = atoi(argv[2]);
    int *arr = malloc(size * sizeof(int));
    if (!arr) {
        printf("Error: Failed to allocate memory\n");
        return 1;
    }
    for (int i = 0; i < size; i++) {
        arr[i] = i;
    }
    srand(seed);
    for (int i = 0; i < size; i++) {
        int j = rand() % size;
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
		printf("Array:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("Shuffled Array:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    qsort(arr, size, sizeof(int), compare);
    printf("Sorted Array:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    free(arr);
    return 0;
}

